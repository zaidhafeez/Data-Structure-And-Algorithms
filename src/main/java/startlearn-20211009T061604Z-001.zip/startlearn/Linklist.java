/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */

class Node{
    int info;
    Node next;
}

public class Linklist {
    Node start;
    

    Linklist() {
        this.start = null;
    }
    
    // INSERTION AT BEGINNING IN THE LINKED LIST //
    
    void insertAtBegin(int item){
        Node n = new Node();
        n.info = item;
        n.next = start;
        start = n;
    }
    
    // INSERTION AT THE END IN LINKED LIST //
    
    void insertAtEnd(int item){
        Node n = new Node();
        n.info = item;
        n.next = null;
        if(start == null){
            start = n;
        }
        else{
            Node p = start;
            while(p.next != null){
                p = p.next;
            }
            p.next = n;
        }
    }
    
    // INSERTION AFTER GIVEN VALUE //
    
    void insertAfterValue(int item, int searchItem){
        if(start == null){
            System.out.println("Linked list is empty");
        }
        Node p = searching(searchItem);
        if(p == null){
            System.out.println("item is not found - insertion is not possible");
        }
        Node n = new Node();
        n.info = item;
        n.next = p.next;
        p.next = n;
    }
    
    // TRAVERSING THE LINKED LIST //
    
    void traverse()
    {
        if(start == null){
            System.out.println("Linked List is empty");
            return;
        }
        Node p = start;
        while(p != null)
        {
            System.out.println(p.info);
            p =p.next;
        }
    }
    
    // SEARCHING THE GIVEN ITEM IN THE LINKED LIST //
    
    Node searching(int searchItem){
        Node p = start;
        while(p != null){
            if(p.info == searchItem){
                return p;
            }
            p = p.next;
        }
        return null;
    }
    
    // DELETION AT BEGINNING IN THE LINKED LIST //
    
    void delAtBegin(){
        if(start == null){
            System.out.println("linked list is empty");
        }
        Node p = start;
        start = start.next;
        p = null;
    }
    
    // DELETION AT END IN THE LINKED LIST //
    
    void delAtEnd(){
        if(start == null){
            System.out.println("Linked List is empty");
        }
        
        if(start.next == null){
            delAtBegin();
        }
        Node p = start.next;
        Node pp = start;
        while(p.next != null){
            pp = p;
            p = p.next;    
        }
        pp.next = null;
        p = null;    
    }
    
    // DELETION OF NODE CONTAINING VALUE //
    
    void delAtGivenValue(int searchItem){
        if(start == null){
            System.out.println("Linked list is empty");
        }
        if(start.info == searchItem){
            delAtBegin();
        }
        else{
            Node p = start.next;
            Node pp = start;
            while(p != null){
                if(p.info == searchItem){
                    break;
                }
                else{
                    pp = p;
                    p = p.next;
                }
            }
            if(p == null){
                System.out.println("item not found del is not possible");
                return;
            }
            pp.next = p.next;
            p = null;
        }
    }
    
    // DESTRUCTOR // 
    
//    void destructor(){
//        Node p = start, ps;
//        start = null;
//        while(p != null){
//            ps = p.next;
//            p = null;
//            p = ps;
//        }
//        System.out.println("link list destruct");
//    }
}
