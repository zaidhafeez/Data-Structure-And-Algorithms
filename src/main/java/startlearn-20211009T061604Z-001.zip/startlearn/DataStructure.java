/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;
import java.util.Scanner;
/**
 *
 * @author Faisal
 */

public class DataStructure {
        
    public static void main(String[] args) {
       /* 
        // Stack Implementation //
        
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int item;
        Stack a = new Stack(n);
        for(int i = 0; i < n; i++){
            item = sc.nextInt();
            a.push(item);
        }
        
        System.out.println(a.peep(5));
 
        for(int i = 0; i < 2; i++){
            System.out.println(a.pop());
        }
        
        a.show();
        */
       /*
       
       // Queue Implementation //
       
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int item;
       Queue q = new Queue(n);
       for(int i = 0; i < n; i++){
           item = sc.nextInt();
           q.enqueue(item);
       }
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        q.enqueue(17);
        q.enqueue(18);
        q.enqueue(19);
        q.show();
        */
       /*
       // LINKED LIST IMPLEMENTATION //

       Linklist obj = new Linklist();
        obj.insertAtBegin(15);
        obj.insertAtBegin(20);
        obj.insertAtEnd(40);
        
        System.out.println(obj.searching(20));
        obj.delAtBegin();
        obj.insertAfterValue(25, 15);
        obj.traverse();
        obj.delAtEnd();
        obj.delAtGivenValue(30);
        obj.traverse();
        obj.destructor();
        obj.traverse();
        */
       
        
       // SINGLY CIRCULAR LINKED LIST //
       
        SinglyCircularLinkedList c = new SinglyCircularLinkedList();
        c.insertAtBegin(25);
//        c.insertAtBegin(15);
//        c.insertAtBegin(10);
//        c.insertAtEnd(30);
//        c.insertAtEnd(35);
//        c.insertAtEnd(40);
//        c.insertAfterGivenValue(5, 10);
//        c.insertAfterGivenValue(45, 40);
//        c.insertAfterGivenValue(27, 25);
//        c.delAtBegin();
//        c.delAtBegin();
//        c.delAtGivenValue(40);
//        c.delAtGivenValue(45);
//        c.delAtGivenValue(40);
        c.delAtEnd();
        c.insertAtBegin(26);
//        c.delAtGivenValue(27);
//        c.insertAfterGivenValue(27, 25);
//        c.delAtEnd();*/
//        c.delAtEnd(); c.delAtGivenValue(23);/*
//        c.delAtGivenValue(25);
        c.delAtEnd();
//        c.insertAtBegin(35);
//        c.insertAtEnd(40);
//        c.delAtBegin();
//        c.delAtEnd();
//        c.delAtGivenValue(15);
        c.traverse(); 
       
        
    }
          
}
