/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */
public class Queue {
    
    int queue[];
    int front;
    int rear;
    int item;
    
    Queue(int size){
        this.front = -1;
        this.rear = -1;
        this.queue = new int[size];
    }
    
    void enqueue(int item){
        if(rear == queue.length - 1){
            System.out.println("QUEUE FULL - INSERTION IS NOT POSSIBLE");
        }
        if(rear == -1){
            front = rear = 0;
        }
        else{
            rear++;
        }
        
        queue[rear] = item;
    }
    
    int dequeue(){
        if(front == -1){
            System.out.println("QUEUE IS EMPTY - DELETION IS NOT POSSIBLE");
            return Integer.MIN_VALUE;
        }
        item = queue[front];
        if(front == rear){
            front = rear = -1;
        }
        else{
            front++;
        }
        return item;
    }
    
    void shiftingQueue(){
        
        int j = 0;
        
        if(front > 0 && rear == queue.length - 1){
         
            for(int i = front; i <= rear; i++){
                queue[j] = queue[i];
                j++;
            }
        }
        front = 0;
        rear = j - 1;
        System.out.println(rear);
    }
    
    void show(){
        for(int a : queue){
            System.out.println("item in queue is " + a);
        }
    }
}
