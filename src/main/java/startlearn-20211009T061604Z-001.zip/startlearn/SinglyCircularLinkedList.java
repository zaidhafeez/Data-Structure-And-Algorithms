/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */
class Node1{
    int info;
    Node1 next;
}
class SinglyCircularLinkedList {
    Node1 head = null;
    Node1 tail = null;
    
    
    void insertAtBegin(int item){
        Node1 n = new Node1();
        if(head == null){
            n.info = item;
            n.next = n;
            head = n;
            tail = n;
            
        }
        else{
            n.info = item;
            n.next = head;
            head = n;
            tail.next = n;
        }   
    }
    
    void insertAtEnd(int item){
        Node1 n = new Node1();
        if(head == null){
            n.info = item;
            n.next = n;
            head = n;
            tail = n;
        }
        else{
            n.info = item;
            n.next = head;
            tail.next = n;
            tail = n;
        }    
    }
    
    void insertAfterGivenValue(int item, int searchItem){
        Node1 p = searching(searchItem);
//        System.out.println(p);
        if(p == null){
            System.out.println("Item Not Found");
        }
        else{
            Node1 n = new Node1();
            if(p.next == head){
                insertAtEnd(item);
            }
            else{
                n.info = item;
                n.next = p.next;
                p.next = n;
            }    
        }
//        System.out.println(tail.info);
    }
    
    void delAtBegin(){
        if(head == null){
            System.out.println("List is empty");
        }
        else{
            if(head==tail)
            {
               head=tail=null; 
            }
            else{
            Node1 p = head;
            head = head.next;
            tail.next = head;
            p = null;
            }
        }
       
    }
    
    void delAtEnd(){
        Node1 p = head;
        if(head == tail){
            head = tail = null;
        }
        else{
        while(p.next != head){
            tail = p;
            p = p.next;
        }
        tail.next = head;
        p= null;
        }
    }
    
    void delAtGivenValue(int searchItem){
        Node1 p = head.next;
        Node1 temp = head;
        if(head.info == searchItem){
            delAtBegin();
        }
        else{
            while(p != head){
                
                if(p.info == searchItem){
                    break;
                }
                else{
                    temp = p;
                    p = p.next;
                    
                }
            }
            temp.next = p.next;
//            System.out.println(p.next);
//            tail.next = head;
            p = null;
        }
//            System.out.println(head.info + " " + tail.info);
    }
    
    void traverse(){ 
        Node1 p = head;
        do{
            if(p!=null)
            {
            System.out.println(p.info);
            p = p.next;
            }
        }while(p != head);   
    }
    
    Node1 searching(int searchItem){
        Node1 p = head;
        if(p.info == searchItem){
            return p;
        }
        else{
            p = p.next;
            while(p != head){
                if(p.info == searchItem){
                    return p;
                }
                p = p.next;
            }
            return null;
        }
    }  
}
