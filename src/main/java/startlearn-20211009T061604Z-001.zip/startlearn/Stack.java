/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */
public class Stack {
    
    int stack[];
    int top;
    int item;
    
    Stack(int n){
       
        this.stack = new int[n];
        this.top = -1;
    }
    /*
     push operation
    */
    void push(int item){
        if(top == stack.length - 1){
            System.out.println("Stack is Full");
            return;
        }
        else{
            stack[++top] = item;
        }
        
    }
    /*
     pop operation
    */
    int pop(){
          
        if(top == -1){
            System.out.println("Stack is empty");
            return Integer.MIN_VALUE;
        }
        else{
            
            item = stack[top--];
           
           
        }
        return item;
    }
    /*
     peep operation
     It returns the value of ith item from the top of stack.
    */
    int peep(int itemIndex){
        
        if(itemIndex < 1 || itemIndex > (top + 1)){
            System.out.println("Invalid Index, This Index not exist in STACK");
            return Integer.MIN_VALUE;
        }
        else{
            item = stack[top-itemIndex + 1];
        }
        return item;
        
    }
    /*
    showing the value of stack
    */
    public void show(){

        for(int i = stack.length - 1; i >= 0; i--){
            System.out.printf("\nItems in Stack %d are :" + stack[i],i);
        }
        
        System.out.println("");
        
    }
   
}
              
