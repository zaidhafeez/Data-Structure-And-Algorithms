/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;
import java.util.Scanner;
/**
 *
 * @author Faisal
 */
class learn{
    Scanner s; 
    private final int number;
    private int temp;
    private int rev_number;
    private int lsd;

    
    learn(){
        
       this.s= new Scanner(System.in);
       this.number = s.nextInt();
 
    }

    public int toReverseNumber(){
        temp = number;
        while(temp != 0){
            lsd = temp % 10;
            rev_number = rev_number * 10 + lsd;
            temp = temp / 10;
        }
        return rev_number;
    }
    
    public boolean checkPalindrome(){
        
        return rev_number == number;
    }
    
    
    
}

public class HelloWorld {

    public static void main(String arg[]){
        System.out.println("Please Enter Number");
        learn obj = new learn();
        obj.toReverseNumber();
        System.out.println(obj.checkPalindrome()?"Palindrome":"Not Palindrome");
        
    }
    
}
