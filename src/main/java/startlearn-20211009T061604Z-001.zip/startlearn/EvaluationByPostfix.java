/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */

class PostfixEvaluate{
    int stack[];
    int top;
    int item;
    
    PostfixEvaluate(int n){
        this.stack = new int[n];
        this.top = -1;
    }
    
    void push(int item){
        if(top == stack.length - 1){
            System.out.println("Stack is Full");
        }
        else{
            stack[++top] = item;
        }
    }
    
    int pop(){
        if(top == -1){
            System.out.println("Stack is Empty");
            return Integer.MIN_VALUE;
        }
        else{
            item = stack[top--];
        }
        return item;
    }
    
    int postfixExpression(String[] item){
        for(int i = 0; i < item.length; i++){
            if(item[i].equals("+") || item[i].equals("-") || item[i].equals("*") || item[i].equals("/") || item[i].equals("^")){
                evaluatePostfix(item[i]);
            }
            else{
                int value = Integer.parseInt(item[i]);
                push(value);
            }
        }
        return pop();
        
    }
    
    void evaluatePostfix(String operator){
        int result = 0,operand1=0,operand2=0;
        switch(operator){
            case "+":
                operand2 = pop();
                operand1 = pop();
                result = operand1 + operand2;
                push(result);
                break;
            case "-":
                operand2 = pop();
                operand1 = pop();
                result = operand1 - operand2;
                push(result);
                break;
            case "*":
                operand2 = pop();
                operand1 = pop();
                result = operand1 * operand2;
                push(result);
                break;
            case "/":
                operand2 = pop();
                operand1 = pop();
                result = operand1 / operand2;
                push(result);
                break;
            case "^":
                operand2=pop();
                operand1=pop();
                result = (int)Math.pow(operand1,operand2);
                push(result);
                break;
        }
    }   
}
    

public class EvaluationByPostfix {
    public static void main(String[] args){
        String item[] = {"2", "5" , "^", "32", "12", "8", "-", "/", "2", "*", "/", "10", "+"};
        int n = item.length;
        PostfixEvaluate pe = new PostfixEvaluate(n);
        System.out.println(pe.postfixExpression(item));
        
        
    }
    
}
