/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startlearn;

/**
 *
 * @author Faisal
 */ 

class Node2{
    int info;
    Node2 BP;
    Node2 FP;
}

class DoublyLinkedList{
    Node2 first;
    Node2 last;
    
    
    void insertAtBegin(int item){
        Node2 n = new Node2();
        
        if(first == null && last == null){
            n.info = item; 
            n.BP = null;
            n.FP = null;
            first = n;
            last = n;
             
        }
        
        else{
            n.info = item;
            n.BP = null;
            n.FP = first;
            first.BP = n;
            first = n; 
        }
    }
    
    void insertAtEnd(int item){
        Node2 n = new Node2();
        if(first == null && last == null){
            insertAtBegin(item);
        }
        else{
            n.info = item;
            n.BP = last;
            n.FP = null;
            last.FP = n;
            last = n;
        }
    }
    
    void insertAfterValue(int item, int searchItem){
        Node2 p = searching(searchItem);
        Node2 n = new Node2();
//        System.out.println(p.info);
        if(p == null){
            System.out.println("Item not Found - Insertion is not possible");
        }
        if(p.FP == null){
            insertAtEnd(item);
        }
        else{
            n.info = item;
            n.FP = p.FP;
            n.BP = p.BP.FP;
            p.FP = n;
        }
    }
    
    void delAtBegin(){
        Node2 p = first;
        if(first == null && last == null){
            System.out.println("list is empty - deletion is not possible");
        }
        if(first == last){
            first = null;
            last = null;
        }
        else{
            first = p.FP;
            first.BP = null;
            p = null;
        }
    }
    
    void delAtEnd(){
        if(first == null && last == null){
            System.out.println("List is Empty");
        }
        if(first == last){
            first = last = null;
        }
        else{
            last = last.BP;
            last.FP = null;
        }
    }
    
    void delAtGivenValue(int searchItem){
        Node2 p = searching(searchItem);
        if(p == null){
            System.out.println("Item is not found - deletion is not possible");
        }
        else{
            if(p.FP == null){
                delAtEnd();
            }
            else if(p.BP == null){
                delAtBegin();
            }
            else{
//                System.out.println(p.BP+""+p.BP.FP);
                p.BP.FP = p.FP;
                p.FP.BP = p.BP;
            }
        }
    }
    
    Node2 searching(int searchItem){
        Node2 p = first;
        while(p != null){
            if(p.info == searchItem){
                return p;
            }
            else{
                p = p.FP;
            }
        }
        return null;
    }
    
    void traverse(){
        Node2 p = first;
        if(first == null && last == null){
            System.out.println("List is Empty");
        }
        while(p != null){
            System.out.println(p.info);
            p = p.FP;
        }
    }
}
public class Test {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();
        dll.insertAtBegin(15);
        dll.insertAtBegin(25);
//        dll.insertAtBegin(35);
//        dll.insertAtBegin(45);
//        dll.insertAtBegin(55);
//        dll.insertAtEnd(60);
//        dll.insertAtEnd(70);
//        dll.insertAtEnd(80);
   //     dll.insertAfterValue(65, 60);
 //       dll.insertAfterValue(85, 80);
//        dll.insertAfterValue(90, 15);
//        dll.delAtBegin();
//        dll.delAtBegin();
 //       dll.delAtEnd();
        dll.delAtGivenValue(25);
        dll.delAtGivenValue(85);
//        System.out.println(dll.searching(65));
        dll.traverse();
    }
}
